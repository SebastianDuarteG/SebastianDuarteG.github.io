To run application:<br />

1. initialize node.js with app.js as entry point <br />
2. install node dependencies: express, multer, sqlite, sqlite3 <br />
3. run nodemon app.js on terminal.
4. Open index.html and use app. 